#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define BUFFER_SIZE 1000

int countOccurrences(FILE *fptr,const char *word);


int main()
{
    FILE *fptr;
    char name1[10] = "luke";
    char name2[10] = "wayne";
	char name3[10] = "rooney";
	char name4[10] = "shaw";
	char name5[10] = "mike";
	char name6[10] = "ronaldo";
    char word[50];

    int wCount,wCount1,wCount2;
    printf("Enter name: ");
    scanf("%s", word);

    fptr = fopen("family.txt", "r");
	if(strcmp(word,name4)==0)
	{
		wCount = countOccurrences(fptr, name1);
	}
	else if(strcmp(word,name3)==0)
	{
		wCount1 = countOccurrences(fptr, name2);
		wCount2 = countOccurrences(fptr, name4);
		wCount = wCount1+wCount2;
	}
	else if(strcmp(word,name6)==0)
	{
		wCount = countOccurrences(fptr, name3);
	}
	else
	{
		wCount = countOccurrences(fptr, name5);
	}

    printf("'%s' has %d grandchildren", word, wCount-1);

    fclose(fptr);

    return 0;
}

int countOccurrences(FILE *fptr, const char *word)
{
    char str[BUFFER_SIZE];
    char *pos;

    int index, count;
    
    count = 0;

    while ((fgets(str, BUFFER_SIZE, fptr)) != NULL)
    {
        index = 0;

        while ((pos = strstr(str + index, word)) != NULL)
        {

            index = (pos - str) + 1;

            count++;
        }
    }

    return count;
}
