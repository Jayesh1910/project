#include <stdio.h>
#include <stdlib.h>

int main ()
{
  int n;
  scanf ("%d", &n);
  
  char *s = (char *) malloc (sizeof (char) * 100);
  scanf ("%s", s);

  int i, j = 0, len = n, f;
  do
    {
      f = 0;
      for (i = 0; i < len - 1; i++)
 {
   if (*(s + i) == *(s + i + 1))
     {
       f = 1;
       for (j = i; j < len - 2; j++)
  {
    *(s + j) = *(s + j + 2);
  }
       len = len - 2;
     }
   s[len] = '\0';
 }
    }
  while (f == 1 && len > 0);
  if (len == 0)
    printf ("Empty String");
  else
    printf ("%s", s);

}